# UniLex

An English academic dictionary for CS and AI students, extending the team's original FastAPI and HTML/CSS/JS project. This version implements the technical workflow in the six supplied requirements screenshots. Read `START_HERE_AR.md` for a short Arabic handoff and `REQUIREMENTS.md` for evidence per requirement.

## Start on macOS

Install Python 3.11 or 3.12, open Terminal in the extracted project folder and run:

```sh
bash start-mac.command
```

The script creates a local virtual environment, installs the dependencies, prepares the data and starts the server. The first run needs internet to download the libraries and the MiniLM model. After `Application startup complete`, open http://127.0.0.1:8000/app/ . Keep Terminal open. Stop with Control+C. This does not publish anything or require hosting payment. The launcher was syntax-checked on Linux; an actual Mac was not available for testing.

Manual equivalent:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
python scripts/prepare_data.py
uvicorn main:app --app-dir backend --port 8000
```

To deliberately run keyword search and extraction without the model, prefix the final command with `UNILEX_DISABLE_SEMANTIC=1`. The UI reports model availability. API documentation is at `/docs`.

## Data and NLP

The original 3,066-row CSV and notebooks are retained. `scripts/prepare_data.py` normalizes whitespace, validates all eight required fields and difficulty values, combines 20 reviewed duplicate groups (21 redundant records), records four editorial corrections and adds one documented PCA entry required by the example in the screenshots. Result: 3,046 canonical entries across 37 categories.

The runtime reads `data/knowledge_base.json`. It contains stable IDs, aliases, original source rows and records, domain grouping and resolved related links. `data/preparation_report.json` records transformations and unresolved references. The category-based AI/CS grouping is a display aid; some topics are interdisciplinary. Related terms without a unique entry remain text rather than broken links. All source records survive in the knowledge base provenance. This is a complete structural data pass with targeted content corrections, not a claim of scientific verification of every definition.

TF-IDF uses NLTK Porter stemming and cosine similarity as the baseline. SBERT uses `sentence-transformers/all-MiniLM-L6-v2` and cosine similarity. Both index the same concise term-plus-definition text; long synthetic examples are displayed but excluded from indexing to reduce topic drift. No model training is performed. Embedding cache keys incorporate model name and the entire ordered text list, so data changes invalidate the cache.

spaCy PhraseMatcher recognizes dictionary phrases and unambiguous aliases, favors longest overlapping spans and returns exact character offsets and repeated mentions. It does not infer absent concepts or match arbitrary inflections. The lecture example in the screenshots returns Machine Learning, Overfitting and the Training Dataset entry via its Training Data alias.

Search returns stored definitions, simplified explanations, examples and related terms. It does not generate new answers to why-questions. Similarity scores are not probabilities.

## API

- `GET /health` — source count, prepared count, model availability.
- `GET /term/{name}` — canonical term or unambiguous alias, including PCA and ML.
- `GET /entry/{id}` — stable ID lookup for related links.
- `GET /categories` — categories and domains for filters.
- `GET /search?q=...&top_k=5` — keyword retrieval.
- `GET /search/semantic?q=...&top_k=5` — semantic retrieval.
- Both search routes accept optional `category` and `domain=AI|CS` filters.
- `POST /extract` with `{"text":"Machine learning can suffer from overfitting."}`.
- `/app/` — web UI; `/app/testing.html` — anonymous feedback form with local JSON download.

## Tests and measured evaluation

```sh
pip install -r requirements-dev.txt
UNILEX_TEST_SEMANTIC=1 python -m pytest tests -q
python evaluation/evaluate.py --semantic
python -m playwright install chromium
# With the local server running on port 8000:
python tests/browser_check.py http://127.0.0.1:8000
```

The 36 developer-authored queries and multi-relevance labels are in `evaluation/queries.json`; results are in `evaluation/results.json`. Labels are not exhaustive or independently validated, and these development queries were used during debugging. Do not present the results as unbiased held-out accuracy. `evaluation/STUDENT_TESTING.md` explains the real student study, which has not been conducted. The UI feedback export was tested with explicitly synthetic TEST-ONLY data, not student responses.

Actual local-browser screenshots are in `screenshots/`. `VALIDATION.md` records checks and limitations.

## Deployment

The revised Render blueprint uses one web service that serves the API and frontend at `/app/`. Build: `bash backend/build.sh`. Start: `uvicorn main:app --app-dir backend --host 0.0.0.0 --port $PORT`. Health route: `/health`. Linux builds install CPU-only PyTorch.

No external GitHub push, Render deployment or billing change has been made. Account connection is required to publish. The blueprint selects `free`; this does not establish that SBERT fits free-host memory. Verify host logs and actual memory before relying on it. No paid plan is automatically chosen. The model/cache may need to download or rebuild on a fresh host.

For an existing separately hosted frontend, set its `frontend/config.js` to the real API HTTPS URL and retain that deployment structure. Review the blueprint before applying it over the team's live services; no deletion of an existing service is needed to test this package locally.
