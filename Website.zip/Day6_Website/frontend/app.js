// Point this at your deployed backend URL once you deploy to Render.
// Left as relative paths here so it also works if the frontend is served
// from the same host as the API (see DEPLOYMENT.md).
const API_BASE = (window.UNILEX_API_BASE || "").replace(/\/$/, "");

const searchInput = document.getElementById("search-input");
const searchBtn = document.getElementById("search-btn");
const searchStatus = document.getElementById("search-status");
const resultsEl = document.getElementById("results");

const lectureInput = document.getElementById("lecture-input");
const extractBtn = document.getElementById("extract-btn");
const extractResultsEl = document.getElementById("extract-results");

function getSearchMode() {
  return document.querySelector('input[name="mode"]:checked').value;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function renderEntry(entry) {
  const links = entry.related_links || [];
  const related = (entry.related_terms || []).map(t => {
    const target = links.find(link => link.term === t && link.id);
    return target ? `<button type="button" class="related-chip" data-entry="${escapeHtml(target.id)}">${escapeHtml(t)}</button>`
      : `<span class="related-chip">${escapeHtml(t)}</span>`;
  }).join("");

  return `
    <article class="entry-card">
      <h3>${escapeHtml(entry.term)}</h3>
      ${typeof entry.score === "number" ? `<p class="hint">Similarity: ${entry.score.toFixed(3)} (not a confidence probability)</p>` : ""}
      ${entry.mentions ? `<p class="hint">Found: ${entry.mentions.map(m => escapeHtml(m.text)).join(", ")}</p>` : ""}
      <div class="entry-meta">
        <span class="badge">${escapeHtml(entry.category)}</span>
        <span class="badge">${escapeHtml(entry.difficulty)}</span>
      </div>

      <div class="entry-section">
        <div class="label">Student-friendly explanation</div>
        <div>${escapeHtml(entry.student_friendly_explanation)}</div>
      </div>

      <div class="entry-section">
        <div class="label">Formal definition</div>
        <div>${escapeHtml(entry.formal_definition)}</div>
      </div>

      ${entry.example ? `
      <div class="entry-section">
        <div class="label">Example</div>
        <div>${escapeHtml(entry.example)}</div>
      </div>` : ""}

      ${related ? `
      <div class="entry-section">
        <div class="label">Related terms</div>
        <div class="related-terms">${related}</div>
      </div>` : ""}
      <p class="source">Source: ${escapeHtml(entry.source)}</p>
    </article>
  `;
}

function renderEmpty(message) {
  resultsEl.innerHTML = `<p class="status">${escapeHtml(message)}</p>`;
}

async function runSearch() {
  const query = searchInput.value.trim();
  if (!query) return;

  const mode = getSearchMode();
  const endpoint = mode === "semantic" ? "/search/semantic" : "/search";
  const params = new URLSearchParams({q: query, top_k: "5"});
  const category = document.getElementById("category-filter").value;
  const domain = document.getElementById("domain-filter").value;
  if (category) params.set("category", category);
  if (domain) params.set("domain", domain);

  searchBtn.disabled = true;
  searchStatus.textContent = "Searching...";
  searchStatus.classList.remove("error");
  resultsEl.innerHTML = "";

  try {
    const res = await fetch(`${API_BASE}${endpoint}?${params}`);
    const data = await res.json();

    if (!res.ok) {
      searchStatus.textContent = typeof data.detail === "string" ? data.detail : "Please check your search input.";
      searchStatus.classList.add("error");
      return;
    }

    searchStatus.textContent = `${data.results.length} result(s) — ${mode === "semantic" ? "smart" : "keyword"} search`;

    if (data.results.length === 0) {
      renderEmpty("No matching terms found. Try different words.");
      return;
    }

    resultsEl.innerHTML = data.results.map(renderEntry).join("");
  } catch (err) {
    searchStatus.textContent = "Could not reach the UniLex API. Is the backend running?";
    searchStatus.classList.add("error");
  } finally {
    searchBtn.disabled = false;
  }
}

async function runExtract() {
  const text = lectureInput.value.trim();
  if (!text) return;

  extractBtn.disabled = true;
  extractResultsEl.innerHTML = `<p class="status">Scanning text...</p>`;

  try {
    const res = await fetch(`${API_BASE}/extract`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    const data = await res.json();

    if (!res.ok) {
      extractResultsEl.innerHTML = `<p class="status error">${escapeHtml(typeof data.detail === "string" ? data.detail : "Enter 1–20,000 characters of lecture text.")}</p>`;
      return;
    }

    if (data.terms_found.length === 0) {
      extractResultsEl.innerHTML = `<p class="status">No known UniLex terms found in that text.</p>`;
      return;
    }

    extractResultsEl.innerHTML = data.terms_found.map(renderEntry).join("");
  } catch (err) {
    extractResultsEl.innerHTML = `<p class="status error">Could not reach the UniLex API.</p>`;
  } finally {
    extractBtn.disabled = false;
  }
}

searchBtn.addEventListener("click", runSearch);
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") runSearch();
});
extractBtn.addEventListener("click", runExtract);

async function checkStatus() {
  const status = document.getElementById("service-status");
  try {
    const response = await fetch(`${API_BASE}/health`);
    if (!response.ok) throw new Error("Unavailable");
    const data = await response.json();
    const semantic = document.querySelector('input[value="semantic"]');
    semantic.disabled = !data.semantic_search_available;
    status.textContent = `${data.terms_loaded} terms • ${data.semantic_search_available ? "Keyword and smart search ready" : "Keyword search ready; smart search unavailable"}`;
  } catch {
    status.textContent = "Service is starting or unavailable. Please try again shortly.";
  }
}
checkStatus();

fetch(`${API_BASE}/categories`).then(r => r.ok ? r.json() : Promise.reject()).then(data => {
  const select = document.getElementById("category-filter");
  data.categories.forEach(category => {
    const option = document.createElement("option");
    option.value = category; option.textContent = category; select.appendChild(option);
  });
}).catch(() => {});

document.addEventListener("click", async event => {
  const button = event.target.closest("button[data-entry]");
  if (!button) return;
  button.disabled = true;
  try {
    const response = await fetch(`${API_BASE}/entry/${encodeURIComponent(button.dataset.entry)}`);
    if (!response.ok) throw new Error();
    resultsEl.innerHTML = renderEntry(await response.json());
    searchStatus.textContent = "Related dictionary entry";
    resultsEl.scrollIntoView({behavior: "smooth", block: "start"});
  } catch { searchStatus.textContent = "Unable to open this entry. Please try again."; }
  finally { button.disabled = false; }
});
