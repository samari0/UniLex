#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# CPU-only PyTorch on the Linux host avoids unnecessary CUDA packages.
if [ "$(uname -s)" = "Linux" ]; then
  python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
fi
python -m pip install -r requirements.txt
python ../scripts/prepare_data.py
