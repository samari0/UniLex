#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON=""
for candidate in python3.12 python3.11 python3; do
  if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; assert (3,11)<=sys.version_info[:2]<=(3,12)' 2>/dev/null; then
    PYTHON="$candidate"; break
  fi
done
if [ -z "$PYTHON" ]; then
  echo "Install Python 3.11 or 3.12 from python.org, then run again."
  read -r -p "Press Enter to close."; exit 1
fi
[ -d .venv ] || "$PYTHON" -m venv .venv
source .venv/bin/activate
python -m pip install -r backend/requirements.txt
python scripts/prepare_data.py
printf '\nOpen http://127.0.0.1:8000/app/ after Application startup complete.\nKeep this Terminal window open. Stop with Control+C.\n'
python -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000
