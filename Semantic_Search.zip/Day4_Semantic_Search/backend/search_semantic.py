"""SBERT retrieval with a content-addressed embedding cache."""
import hashlib
import json
import os
from pathlib import Path
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"


class SemanticSearch:
    def __init__(self, df, search_texts, cache_dir=None):
        self.df = df
        self.model = SentenceTransformer(MODEL_NAME, device="cpu")
        cache_dir = Path(cache_dir or os.getenv("UNILEX_CACHE_DIR", Path(__file__).parent / ".cache"))
        cache_dir.mkdir(parents=True, exist_ok=True)
        fingerprint = hashlib.sha256(json.dumps([MODEL_NAME, search_texts], ensure_ascii=False).encode()).hexdigest()
        path = cache_dir / (fingerprint + ".npy")
        self.embeddings = None
        if path.exists():
            try:
                arr = np.load(path, allow_pickle=False)
                if arr.shape == (len(search_texts), self.model.get_sentence_embedding_dimension()) and np.isfinite(arr).all():
                    self.embeddings = arr
            except (OSError, ValueError):
                pass
        if self.embeddings is None:
            self.embeddings = self.model.encode(search_texts, batch_size=32, convert_to_numpy=True,
                                                normalize_embeddings=True, show_progress_bar=False)
            temporary = path.with_suffix(".tmp")
            with temporary.open("wb") as stream:
                np.save(stream, self.embeddings)
            temporary.replace(path)

    def search(self, query, top_k=5):
        vector = self.model.encode([query], convert_to_numpy=True, normalize_embeddings=True)
        scores = cosine_similarity(vector, self.embeddings).ravel()
        return [{"index": int(i), "score": float(scores[i])}
                for i in np.argsort(-scores, kind="stable")[:top_k]]
