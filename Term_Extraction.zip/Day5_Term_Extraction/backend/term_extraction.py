"""Case-insensitive, token-boundary dictionary matching with source offsets."""
import re
from collections import defaultdict
from spacy.matcher import PhraseMatcher
from preprocessing import get_nlp


class TermExtractor:
    def __init__(self, df):
        self.nlp = get_nlp()
        self.matcher = PhraseMatcher(self.nlp.vocab, attr="LOWER")
        candidates = defaultdict(set)
        exact = {t.casefold(): i for i, t in enumerate(df["term"])}
        for idx, term in enumerate(df["term"]):
            candidates[term].add(idx)
            for alias in df.iloc[idx].get("aliases", []):
                candidates[alias].add(idx)
            plain = re.sub(r"^(?:a|an|the)\s+", "", term, flags=re.I)
            candidates[plain].add(idx)
            match = re.fullmatch(r"(.+?)\s*\(([A-Za-z][A-Za-z0-9-]{1,12})\)", plain)
            if match:
                candidates[match[1].strip()].add(idx)
                candidates[match[2]].add(idx)
        # Ambiguous aliases are not silently assigned to a random entry.
        for term, indices in candidates.items():
            normalized = {re.sub(r"^(?:a|an|the)\s+", "", df.iloc[i]["term"], flags=re.I).casefold() for i in indices}
            if term.casefold() in exact or len(normalized) == 1:
                idx = exact.get(term.casefold(), min(indices, key=lambda i: (len(df.iloc[i]["term"]), i)))
                self.matcher.add(str(idx), [self.nlp.make_doc(term)])

    def extract(self, text):
        doc = self.nlp.make_doc(text)
        matches = sorted(self.matcher(doc), key=lambda m: (-(m[2]-m[1]), m[1]))
        occupied = set()
        found = {}
        for key, start, end in matches:
            if occupied.intersection(range(start, end)):
                continue
            occupied.update(range(start, end))
            idx = int(self.nlp.vocab.strings[key])
            span = doc[start:end]
            found.setdefault(idx, []).append({"text": span.text, "start": span.start_char, "end": span.end_char})
        return [{"index": idx, "mentions": sorted(spans, key=lambda s:s["start"])}
                for idx, spans in sorted(found.items(), key=lambda pair:min(s["start"] for s in pair[1]))]
