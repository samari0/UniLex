# Validation performed

The final local version was checked using real MiniLM inference and a real headless Chromium browser.

- 16 automated tests cover API routes, input limits, filters, aliases, extraction offsets and repetitions, punctuation boundaries, provenance conservation and real-model cache invalidation.
- Browser interactions cover keyword and semantic search, the PCA and lecture examples, related links, filters, no results, mobile overflow and feedback download.
- Desktop viewport: 1280×900. Mobile viewport: 390×844. Actual screenshots are in `screenshots/`.
- JavaScript and shell launcher syntax were checked. No actual macOS hardware or Render host was tested.
- Source CSV retained byte-for-byte. 3,066 source rows + 1 sourced addition − 21 redundant entries = 3,046 canonical entries. 20 duplicate groups; 37 categories.
- Dataset preparation reports unresolved related links rather than inventing target entries. All eight fields of every input record were validated. Four targeted scientific/editorial corrections were recorded.

## Development evaluation (36 queries)

| Method | Precision@5 | Recall@5 | MRR@5 | Hit@1 | Hit@5 |
| --- | ---: | ---: | ---: | ---: | ---: |
| tfidf | 0.1667 | 0.5833 | 0.5144 | 0.4167 | 0.7222 |
| sbert | 0.1667 | 0.5556 | 0.4986 | 0.4167 | 0.6389 |

These labels were authored during development and are not exhaustive independent judgments. Some alternative relevant entries count as misses. Queries were used during debugging, so this is not a held-out accuracy estimate. In this final evaluation, SBERT does not outperform TF-IDF overall. Keep both modes; improve the label set with student judgments before making comparative claims.

## External work still required

- Connect authorized GitHub and Render accounts before publishing. No remote repository, live service or billing plan was changed.
- Run the actual student study; provided feedback tooling is ready but no participant responses were fabricated.
- Verify host memory/startup behavior. The free blueprint setting does not guarantee SBERT fits the host.
- Complete an independent scientific content review if required by the course. Structural validation and targeted corrections do not establish universal factual accuracy.

Environment: Python 3.12, CPU PyTorch 2.14.1+cpu, sentence-transformers 3.4.1, transformers 4.57.6, Chromium 134 via Playwright 1.51.0. Starlette emitted a non-failing test-client deprecation warning.
