# Mapping to the six supplied screenshots

| Requirement | Implementation/evidence | Status |
| --- | --- | --- |
| Day 1: analyze 3,066 terms, clean fields, categories, knowledge base/search structure | `scripts/prepare_data.py`, `data/knowledge_base.json`, `data/preparation_report.json`; all input rows retained in provenance, 20 duplicate groups merged, four corrections, one sourced addition | Implemented; no claim that every scientific definition was independently verified |
| Day 2: Python/FastAPI API returning definition, explanation, example, related terms | `backend/main.py`, `backend/data_loader.py`, API tests | Implemented and tested |
| Day 3: preprocessing, TF-IDF, cosine ranking | `backend/preprocessing.py`, `backend/search_tfidf.py` | Implemented and evaluated |
| Day 4: SBERT all-MiniLM-L6-v2 embeddings and cosine ranking | `backend/search_semantic.py`, actual model evaluation and cache regression test | Implemented and tested with real model |
| Day 5: natural-language retrieval and lecture term extraction | `/search/semantic`, spaCy `TermExtractor`, aliases/offsets, screenshot example regression tests | Implemented and browser-tested |
| Student-friendly explanations and examples from dataset | Search/extraction cards | Implemented; retrieval, not generated Q&A |
| Day 6: HTML/CSS/JS UI integrated with FastAPI | `/app/`, category/domain filters, related term navigation, mobile layout, status/errors | Browser-tested locally |
| Day 6: GitHub + Render live website | `render.yaml`, `backend/build.sh`, deployment instructions | Prepared; external publishing blocked until account access is connected |
| Day 7: different queries, measurement, bug fixes | 36-query comparative evaluation, 16 automated tests and browser interaction checks | Implemented; development-set findings only |
| Day 7: student testing | Feedback export form, protocol and analysis script | Tools prepared; real participants must provide responses |
| Day 7: screenshots | `screenshots/01-keyword-desktop.png`, `02-semantic-desktop.png`, `03-lecture-extraction.png`, `04-mobile.png` and viewport previews | Captured from actual local app, not fabricated |

The similarity values 0.89/0.61/0.54 shown in the plan are illustrative and are not copied into the application. Actual model scores are computed per query. Technical completion does not imply that external hosting or the student study happened.
