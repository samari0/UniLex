"""Run against a live local server: python tests/browser_check.py [base URL]."""
import json
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
base=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8765'
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':900})
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(base+'/app/',wait_until='networkidle',timeout=120000)
    page.wait_for_function("document.querySelector('#service-status').textContent.includes('terms')")
    page.fill('#search-input','Why does the model overfit?')
    page.click('#search-btn')
    page.wait_for_selector('#results .entry-card')
    assert 'Overfitting' in page.locator('#results').inner_text()
    page.screenshot(path=str(root/'screenshots/01-keyword-desktop.png'),full_page=True)
    page.check('input[value="semantic"]')
    page.click('#search-btn')
    page.wait_for_function("document.querySelector('#search-status').textContent.includes('smart')")
    assert 'Overfitting' in page.locator('#results').inner_text()
    assert page.locator('#results h3').first.inner_text() == 'Overfitting'
    page.screenshot(path=str(root/'screenshots/02-semantic-desktop.png'),full_page=True)
    page.screenshot(path=str(root/'screenshots/preview-desktop.png'))
    page.fill('#search-input','Why do we use PCA?')
    page.click('#search-btn')
    page.wait_for_function("!document.querySelector('#search-btn').disabled")
    assert 'Principal Component Analysis' in page.locator('#results').inner_text()
    text='Machine learning models can suffer from overfitting when they memorize the training data.'
    page.fill('#lecture-input',text)
    page.click('#extract-btn')
    page.wait_for_selector('#extract-results .entry-card')
    result=page.locator('#extract-results').inner_text()
    for term in ['Machine Learning','Overfitting','Training Dataset']:assert term in result
    page.locator('.extract-section').screenshot(path=str(root/'screenshots/03-lecture-extraction.png'))
    # Related entry buttons must retrieve an actual entry.
    related=page.locator('#extract-results button[data-entry]').first
    related.click()
    page.wait_for_function("document.querySelector('#search-status').textContent === 'Related dictionary entry'")
    page.check('input[value="tfidf"]')
    page.select_option('#domain-filter','CS')
    page.select_option('#category-filter','Databases')
    page.fill('#search-input','data');page.click('#search-btn')
    page.wait_for_function("!document.querySelector('#search-btn').disabled")
    assert page.locator('#results .entry-card').count()>0
    page.select_option('#domain-filter','');page.select_option('#category-filter','')
    page.fill('#search-input','zzzznotawordzzzz');page.click('#search-btn')
    page.wait_for_function("!document.querySelector('#search-btn').disabled")
    assert 'No matching terms' in page.locator('#results').inner_text()
    # Mobile overflow and semantic flow.
    page.set_viewport_size({'width':390,'height':844})
    page.check('input[value="semantic"]')
    page.fill('#search-input','Why does the model overfit?');page.click('#search-btn')
    page.wait_for_selector('#results .entry-card')
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.screenshot(path=str(root/'screenshots/04-mobile.png'),full_page=True)
    page.screenshot(path=str(root/'screenshots/preview-mobile.png'))
    # Feedback form produces real downloadable JSON without server storage.
    page.goto(base+'/app/testing.html')
    for name,value in {'participant':'TEST-ONLY','input':'test query','expected':'test term','returned':'test term','seconds':'10','clarity':'4','ease':'4'}.items():
        page.fill('[name="'+name+'"]',value)
    with page.expect_download() as event:page.click('button[type="submit"]')
    assert event.value.suggested_filename == 'unilex-feedback.json'
    assert not errors,errors
    browser.close()
    (root/'evaluation/browser_results.json').write_text(json.dumps({'status':'passed','desktop':'1280x900','mobile':'390x844','checks':['keyword search','semantic search','PCA example','lecture example','related links','filters','empty results','mobile overflow','feedback export'],'javascript_errors':errors,'participant_data':'TEST-ONLY synthetic form check; not a student study'},indent=2))
    print('Browser checks passed; screenshots saved.')
