import os
import sys
from pathlib import Path
os.environ['UNILEX_DISABLE_SEMANTIC'] = '1'
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
import pytest
from fastapi.testclient import TestClient
from main import app

@pytest.fixture(scope='module')
def client():
    with TestClient(app) as c:
        yield c

def test_health_and_site(client):
    assert client.get('/health').json()['terms_loaded'] == 3046
    assert client.get('/app/').status_code == 200
    assert client.get('/app/app.js').status_code == 200

def test_dictionary(client):
    result = client.get('/term/Overfitting')
    assert result.status_code == 200
    assert result.json()['student_friendly_explanation']
    assert client.get('/term/nonexistent123').status_code == 404

def test_search(client):
    rows = client.get('/search', params={'q':'Why does the model overfit?'}).json()['results']
    assert any(r['term'] == 'Overfitting' for r in rows)
    assert client.get('/search', params={'q':'zzzznotawordzzzz'}).json()['results'] == []

@pytest.mark.parametrize('params', [{'q':' '},{'q':'test','top_k':-1},{'q':'test','top_k':21},{'q':'x'*501}])
def test_search_limits(client, params):
    assert client.get('/search',params=params).status_code == 422

def test_semantic_unavailable(client):
    assert client.get('/search/semantic',params={'q':'overfit'}).status_code == 503

def test_extraction(client):
    text = 'Machine learning uses a CNN. Machine learning can overfit.'
    rows = client.post('/extract',json={'text':text}).json()['terms_found']
    assert any('Convolutional Neural Network' in r['term'] for r in rows)
    ml = next(r for r in rows if r['term'].lower().startswith('machine learning'))
    assert len(ml['mentions']) == 2
    for r in rows:
        for m in r['mentions']:
            assert text[m['start']:m['end']] == m['text']
    assert client.post('/extract',json={'text':'machine. Learning'}).json()['terms_found'] == []

@pytest.mark.parametrize('text',['',' ','a'*20001])
def test_extraction_limits(client,text):
    assert client.post('/extract',json={'text':text}).status_code == 422


def test_prepared_knowledge_and_aliases(client):
    assert client.get('/health').json()['source_rows'] == 3066
    assert client.get('/term/ML').json()['term'] == 'Machine Learning'
    assert 'Principal Component Analysis' in client.get('/term/PCA').json()['term']
    text='Machine learning models can suffer from overfitting when they memorize the training data.'
    entries=client.post('/extract',json={'text':text}).json()['terms_found']
    names={e['term'] for e in entries}
    assert {'Machine Learning','Overfitting','A Training Dataset In Ml'} <= names
    for entry in entries:
        assert client.get('/entry/'+entry['id']).status_code == 200

def test_filters(client):
    response=client.get('/search',params={'q':'data','domain':'CS','category':'Databases'})
    assert response.status_code == 200
    assert all(r['category']=='Databases' and r['domain']=='CS' for r in response.json()['results'])
    assert client.get('/search',params={'q':'data','domain':'invalid'}).status_code == 422
    assert len(client.get('/categories').json()['categories']) == 37

def test_cleaning_provenance():
    import json
    root=Path(__file__).resolve().parents[1]
    kb=json.loads((root/'data/knowledge_base.json').read_text())
    assert len({e['id'] for e in kb['entries']}) == 3046
    rows=[row for e in kb['entries'] for row in e['source_rows'] if row is not None]
    assert sorted(rows) == list(range(2,3068))
    assert len([e for e in kb['entries'] if len(e['source_rows'])>1]) == 20
