"""Run explicitly with UNILEX_TEST_SEMANTIC=1; requires the real model."""
import os
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))

@pytest.mark.skipif(os.getenv('UNILEX_TEST_SEMANTIC')!='1', reason='requires downloaded SBERT model')
def test_real_cache_content_changes(tmp_path):
    import numpy as np
    import pandas as pd
    from search_semantic import SemanticSearch
    df=pd.DataFrame({'term':['cat','database']})
    first=SemanticSearch(df,['a small furry animal','a relational database with tables'],tmp_path)
    second=SemanticSearch(df,['a relational database with tables','a small furry animal'],tmp_path)
    assert len(list(tmp_path.glob('*.npy'))) == 2
    assert np.allclose(first.embeddings[0],second.embeddings[1])
    assert second.search('database tables')[0]['index'] == 0
