# Student evaluation protocol

Status: not conducted.

Recruit CS/AI students with consent. Use anonymous participant IDs; do not collect names in the results.

For each participant, ask them to:
1. Find an unfamiliar term by name and explain it in their own words.
2. Search for the same concept with a natural-language question, once in each search mode. Alternate the order between participants.
3. Paste an English lecture paragraph, review extracted terms and mark missing/incorrect matches.
4. Rate explanation clarity and ease of use from 1 (poor) to 5 (excellent).

Record: participant ID, task, query/text, method, expected relevant terms (reviewed by a human), returned terms, completion time, success, clarity rating, ease rating and comments. Record failures as well as successes.

For a retrieval study, prepare a separate held-out query set before tuning, preferably at least 30–50 queries spanning multiple categories. Multiple relevant entries may be valid: label all of them. Compare both methods on the identical queries using Precision@5, Recall@5 and MRR. Report sample size and labeling procedure. The bundled diagnostic script currently reports Hit@1, Hit@5 and MRR@5 for one target per query; those are not multi-label precision or recall.

Capture real screenshots of keyword results, semantic results and extraction on desktop/mobile after the deployed version is verified. Record service version and date. Do not present a screenshot or test count as proof that all definitions are accurate.
