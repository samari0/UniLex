"""Summarize actual exported feedback files; does not generate responses."""
import json
import statistics
import sys
from pathlib import Path
if len(sys.argv)!=2:raise SystemExit('Usage: python evaluation/analyze_feedback.py path/to/feedback_folder')
rows=[]
for path in sorted(Path(sys.argv[1]).glob('*.json')):
    row=json.loads(path.read_text())
    if str(row.get('participant','')).startswith('TEST-'):continue
    for key in ['participant','task','method','success','seconds','clarity','ease']:
        if key not in row:raise ValueError(f'{path}: missing {key}')
    if row['success'] not in ['Yes','No','Partly']:raise ValueError(f'{path}: invalid success')
    if not (1<=row['clarity']<=5 and 1<=row['ease']<=5 and row['seconds']>=0):raise ValueError(f'{path}: invalid measurement')
    rows.append(row)
if not rows:raise SystemExit('No real participant responses found. No results generated.')
result={'responses':len(rows),'participants':len(set(r['participant'] for r in rows)),
        'successful_tasks':sum(r['success']=='Yes' for r in rows),
        'mean_seconds':statistics.mean(r['seconds'] for r in rows),
        'mean_clarity':statistics.mean(r['clarity'] for r in rows),
        'mean_ease':statistics.mean(r['ease'] for r in rows)}
print(json.dumps(result,indent=2))
