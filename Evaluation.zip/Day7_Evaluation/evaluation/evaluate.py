"""Reproducible multi-relevance diagnostic evaluation; labels need independent review."""
import json
import sys
import time
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'backend'))
from data_loader import load_dataset,build_search_text,alias_index
from search_tfidf import TfidfSearch

def main():
    df=load_dataset();texts=[build_search_text(r) for _,r in df.iterrows()]; aliases=alias_index(df)
    cases=json.loads((root/'evaluation/queries.json').read_text())
    for case in cases:
        case['relevant_indices']=set()
        for term in case['relevant_terms']:
            if term.casefold() not in aliases:raise ValueError('Label absent: '+term)
            case['relevant_indices'].add(aliases[term.casefold()])
    models={'tfidf':TfidfSearch(df,texts)}
    if '--semantic' in sys.argv:
        from search_semantic import SemanticSearch
        models['sbert']=SemanticSearch(df,texts)
    report={'label_status':'Developer-authored relevant sets, not exhaustive independent judgments; no held-out accuracy claim.',
            'query_count':len(cases),'entries':len(df),'k':5,'methods':{}}
    for name,model in models.items():
        details=[]
        for case in cases:
            start=time.perf_counter();hits=model.search(case['query'],top_k=5);ms=(time.perf_counter()-start)*1000
            positions=[i+1 for i,h in enumerate(hits) if h['index'] in case['relevant_indices']]
            details.append({'query':case['query'],'relevant_terms':case['relevant_terms'],
                'returned':[{'term':df.iloc[h['index']].term,'score':round(h['score'],4)} for h in hits],
                'precision_at_5':len(positions)/5,'recall_at_5':len(positions)/len(case['relevant_indices']),
                'reciprocal_rank_at_5':1/min(positions) if positions else 0,
                'hit_at_1':int(1 in positions),'hit_at_5':int(bool(positions)),'milliseconds':round(ms,2)})
        metrics={key:round(float(np.mean([d[key] for d in details])),4) for key in ['precision_at_5','recall_at_5','reciprocal_rank_at_5','hit_at_1','hit_at_5','milliseconds']}
        report['methods'][name]={'metrics':metrics,'queries':details}
    (root/'evaluation/results.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({key:value['metrics'] for key,value in report['methods'].items()},indent=2))

if __name__=='__main__':main()
