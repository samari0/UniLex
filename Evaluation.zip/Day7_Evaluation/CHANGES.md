# Revision history

This revision extends Lamya's original backend and frontend.

- Added reproducible data preparation with canonical entries, stable IDs, provenance, aliases, domain/category metadata, related-link resolution, 20 reviewed duplicate groups, four targeted corrections and a sourced PCA addition. Source CSVs/notebooks retained.
- Fixed working-directory-dependent loading, stale embedding cache, unconstrained API inputs, alias lookup and extraction boundaries; added repeated-mention offsets.
- Indexed term and formal definition consistently in both search methods. Long synthetic examples are displayed but not used to rank entries.
- Integrated frontend/API at `/app/`; retained the option to point a separate frontend at a deployed API.
- Added filters, related navigation, accessibility labels, loading/error states and real browser tests/screenshots.
- Added 36-query evaluation, regression tests, real-student feedback form/protocol/analysis and a macOS launcher.
- Prepared CPU-only Linux build and free Render blueprint. No external deployment or payment action occurred.

See `REQUIREMENTS.md` and `VALIDATION.md` for completion evidence and external dependencies.
