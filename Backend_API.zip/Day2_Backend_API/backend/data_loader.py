"""Validated runtime knowledge base, reproducibly prepared from the source CSV."""
import json
from pathlib import Path
import pandas as pd

DATASET_PATH = Path(__file__).resolve().parents[1] / 'data/knowledge_base.json'
REQUIRED = ['term','formal_definition','student_friendly_explanation','example','category','difficulty','related_terms','source']

def load_dataset(path=DATASET_PATH):
    path=Path(path)
    if path.suffix=='.json':
        payload=json.loads(path.read_text())
        df=pd.DataFrame(payload['entries'])
        metadata=payload['metadata']
    else:
        df=pd.read_csv(path,keep_default_na=False)
        metadata={'source_rows':len(df)}
    df.columns=[c.strip().lstrip('\ufeff') for c in df.columns]
    if any(c not in df for c in REQUIRED): raise ValueError('Dataset missing required fields')
    for field in REQUIRED:
        if field!='related_terms':df[field]=df[field].fillna('').astype(str).str.strip()
    if ((df.term=='') | (df.formal_definition=='')).any(): raise ValueError('Empty term or definition')
    df['term_lower']=df.term.str.casefold()
    if df.term_lower.duplicated().any(): raise ValueError('Duplicate canonical terms')
    df=df.reset_index(drop=True)
    df['row_index']=df.index
    if 'id' not in df:df['id']=['row_'+str(i) for i in df.index]
    if 'aliases' not in df:df['aliases']=[[t] for t in df.term]
    df.attrs['metadata']=metadata
    return df

def build_search_text(row):
    # Definitions convey topic more directly than long synthetic examples.
    return row['term'] + '. ' + row['formal_definition']

def to_entry_dict(row):
    related=row['related_terms']
    if isinstance(related,str):related=[t.strip() for t in related.split(';') if t.strip()]
    return {**{f:row[f] for f in REQUIRED if f!='related_terms'},
            'id':row['id'],'related_terms':related,'domain':row.get('domain',''),
            'aliases':row.get('aliases',[]),'related_links':row.get('related_links',[])}

def alias_index(df):
    found={}
    for idx,row in df.iterrows():
        for alias in row['aliases']:
            found.setdefault(alias.casefold(),set()).add(idx)
    # Exact canonical spelling wins; genuinely ambiguous abbreviations stay unresolved.
    resolved={key:next(iter(ids)) for key,ids in found.items() if len(ids)==1}
    resolved.update({row.term_lower:i for i,row in df.iterrows()})
    return resolved
