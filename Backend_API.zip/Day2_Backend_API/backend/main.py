"""
UniLex backend API (Day 2 of the plan).

Endpoints:
  GET  /                      - health check
  GET  /term/{term_name}      - exact term lookup
  GET  /search                - basic TF-IDF keyword search
  GET  /search/semantic       - SBERT semantic search (natural-language questions)
  POST /extract                - extract known UniLex terms from pasted lecture text
"""
import os
import logging
from pathlib import Path
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator

from data_loader import load_dataset, build_search_text, to_entry_dict, alias_index
from search_tfidf import TfidfSearch
from term_extraction import TermExtractor

STATE = {}

# Semantic search is optional at import time: if the SBERT model can't be
# downloaded (e.g. no internet access), the API still runs with TF-IDF only,
# and /search/semantic returns a clear 503 instead of crashing the whole app.
SEMANTIC_ENABLED = os.environ.get("UNILEX_DISABLE_SEMANTIC", "") != "1"


@asynccontextmanager
async def lifespan(app: FastAPI):
    df = load_dataset()
    search_texts = [build_search_text(row) for _, row in df.iterrows()]

    STATE["df"] = df
    STATE["aliases"] = alias_index(df)
    STATE["tfidf"] = TfidfSearch(df, search_texts)
    STATE["extractor"] = TermExtractor(df)
    STATE["semantic"] = None
    STATE["semantic_error"] = None

    if SEMANTIC_ENABLED:
        try:
            from search_semantic import SemanticSearch
            STATE["semantic"] = SemanticSearch(df, search_texts)
        except Exception as e:
            logging.exception("Semantic model failed to load")
            STATE["semantic_error"] = "Model unavailable; use keyword search."

    yield
    STATE.clear()


app = FastAPI(title="UniLex API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ExtractRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20000)

    @field_validator("text")
    @classmethod
    def nonblank(cls, value):
        if not value.strip():
            raise ValueError("Enter lecture text")
        return value


@app.get("/health")
@app.get("/")
def health():
    df = STATE.get("df")
    return {
        "status": "ok",
        "terms_loaded": int(len(df)) if df is not None else 0,
        "source_rows": df.attrs.get("metadata", {}).get("source_rows", 0) if df is not None else 0,
        "semantic_search_available": STATE.get("semantic") is not None,
        "semantic_search_error": STATE.get("semantic_error"),
    }


@app.get("/term/{term_name:path}")
def get_term(term_name: str):
    df = STATE["df"]
    index = STATE["aliases"].get(term_name.strip().casefold())
    if index is None:
        raise HTTPException(status_code=404, detail=f"Term '{term_name}' not found")
    return to_entry_dict(df.iloc[index])


def filter_hits(hits, df, top_k, category, domain):
    if category and category not in set(df.category):
        raise HTTPException(422, "Unknown category")
    if domain and domain not in {"AI", "CS"}:
        raise HTTPException(422, "Unknown domain")
    return [h for h in hits if (not category or df.iloc[h["index"]]["category"] == category)
            and (not domain or df.iloc[h["index"]]["domain"] == domain)][:top_k]


@app.get("/categories")
def categories():
    df = STATE["df"]
    return {"categories": sorted(df.category.unique().tolist()), "domains": ["AI", "CS"]}


@app.get("/entry/{entry_id}")
def get_entry(entry_id: str):
    df = STATE["df"]
    match = df[df.id == entry_id]
    if match.empty:
        raise HTTPException(404, "Entry not found")
    return to_entry_dict(match.iloc[0])


@app.get("/search")
def search(q: str = Query(..., min_length=1, max_length=500), top_k: int = Query(5, ge=1, le=20), category: str | None = None, domain: str | None = None):
    df = STATE["df"]
    if not q.strip():
        raise HTTPException(422, "Enter a search query")
    hits = STATE["tfidf"].search(q, top_k=len(df))
    hits = filter_hits(hits, df, top_k, category, domain)
    return {
        "query": q,
        "method": "tfidf",
        "results": [
            {**to_entry_dict(df.iloc[h["index"]]), "score": round(h["score"], 4)}
            for h in hits
        ],
    }


@app.get("/search/semantic")
def search_semantic(q: str = Query(..., min_length=1, max_length=500), top_k: int = Query(5, ge=1, le=20), category: str | None = None, domain: str | None = None):
    df = STATE["df"]
    semantic = STATE.get("semantic")
    if semantic is None:
        raise HTTPException(
            status_code=503,
            detail=(
                "Semantic search model is unavailable right now "
                f"({STATE.get('semantic_error') or 'model not loaded'}). "
                "Try /search for TF-IDF keyword search instead."
            ),
        )
    if not q.strip():
        raise HTTPException(422, "Enter a search query")
    hits = semantic.search(q, top_k=len(df))
    hits = filter_hits(hits, df, top_k, category, domain)
    return {
        "query": q,
        "method": "sbert",
        "results": [
            {**to_entry_dict(df.iloc[h["index"]]), "score": round(h["score"], 4)}
            for h in hits
        ],
    }


@app.post("/extract")
def extract_terms(req: ExtractRequest):
    df = STATE["df"]
    hits = STATE["extractor"].extract(req.text)
    return {
        "text_length": len(req.text),
        "terms_found": [{**to_entry_dict(df.iloc[h["index"]]), "mentions": h["mentions"]} for h in hits],
    }


frontend = Path(__file__).resolve().parent.parent / "frontend"
if frontend.is_dir():
    app.mount("/app", StaticFiles(directory=frontend, html=True), name="frontend")
