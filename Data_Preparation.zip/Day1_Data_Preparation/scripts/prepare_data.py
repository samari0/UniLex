"""Reproducible source-to-knowledge-base pipeline. Preserves source CSV unchanged."""
import hashlib
import json
import re
from pathlib import Path
from collections import defaultdict
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ['term','formal_definition','student_friendly_explanation','example','category','difficulty','related_terms','source']
CURATED_MERGES = {'overfitting in machine learning':'overfitting','overfitting in ai':'overfitting','stack data structure':'stack','queue data structure':'queue'}
CURATED_ALIASES = {'A Training Dataset In Ml': ['Training Data', 'Training Dataset']}
CS = {'Algorithms','Cloud Computing','Computer Networks','Cybersecurity','Data Structures','Databases','Operating Systems','Programming Fundamentals','Software Engineering'}

def normalize(term):
    term = re.sub(r'^(?:a|an|the)\s+', '',term.strip(),flags=re.I).rstrip('.?')
    term = re.sub(r'\s*\([A-Za-z][A-Za-z0-9-]{1,12}\)$','',term)
    key = re.sub(r'\s+',' ',term).casefold()
    return CURATED_MERGES.get(key, key)

def aliases(term):
    base = re.sub(r'^(?:a|an|the)\s+', '',term.strip(),flags=re.I).rstrip('.?')
    result = {term, base}
    match = re.fullmatch(r'(.+?)\s*\(([A-Za-z][A-Za-z0-9-]{1,12})\)',base)
    if match: result.update([match[1].strip(),match[2]])
    return result

CORRECTIONS = {
 'Overfitting': {
  'formal_definition':'Overfitting occurs when a model fits training-specific details or noise and generalizes poorly to unseen data. Regularization, early stopping or additional representative data can help; cross-validation helps assess generalization and choose model settings.',
  'reference':'Editorial clarification: validation measures generalization and supports model selection'},
 'Bayesian Personalized Ranking (BPR)': {
  'student_friendly_explanation':'BPR learns a personalized ranking from implicit feedback. For a user, it trains the model to score an interacted-with item above a sampled unobserved item. Unobserved does not necessarily mean disliked.',
  'example':'A listener played song A but has not played song B. Training encourages score(user, A) to exceed score(user, B). Basic BPR uses such item pairs, not the chronological order of listening.',
  'reference':'https://arxiv.org/abs/1205.2618'},
 'Parallel Tool Calls': {
  'student_friendly_explanation':'Independent tool requests can run at the same time. A request that needs another tool result must wait for it.',
  'example':'An assistant can request the weather in two cities simultaneously. It must wait for a search result before opening a URL supplied only by that result.',
  'reference':'Editorial correction consistent with the supplied formal definition'},
 'The Difference Between Pandas Series.Map() And Series.Apply()': {
  'formal_definition':'Series.map substitutes Series values using a function, mapping, or another Series. Series.apply applies a function to Series values by default; in pandas 2.1+, by_row=False passes the whole Series. Row/column axis operations are associated with DataFrame.apply.',
  'student_friendly_explanation':'Use map to replace values with a lookup or a function. Series.apply also supports functions and extra arguments; it does not imply that the input is a whole DataFrame row.',
  'example':"For s = pd.Series([1, 2]), s.map({1: 'one', 2: 'two'}) gives ['one', 'two']; s.apply(lambda x: x + 10) gives [11, 12].",
  'reference':'https://pandas.pydata.org/pandas-docs/version/2.2/reference/api/pandas.Series.map.html ; https://pandas.pydata.org/docs/reference/api/pandas.Series.apply.html'}
}

def main():
    source = ROOT/'backend/unilex_dataset.csv'
    df = pd.read_csv(source,keep_default_na=False,dtype=str)
    df.columns=df.columns.str.strip().str.lstrip('\ufeff')
    assert all(c in df for c in FIELDS)
    groups=defaultdict(list)
    changes=[]
    for number,row in enumerate(df.to_dict('records'),start=2):
        for field in FIELDS:
            old=row[field]; row[field]=re.sub(r'\s+',' ',old).strip()
            if old!=row[field]: changes.append({'row':number,'field':field,'action':'whitespace normalization'})
        assert all(row[f] for f in FIELDS),f'Empty field at row {number}'
        assert row['difficulty'] in {'beginner','intermediate','advanced'}
        row['source_row']=number
        groups[normalize(row['term'])].append(row)
    additions=json.loads((ROOT/'data/additions.json').read_text())
    for row in additions:
        row['source_row']=None
        groups[normalize(row['term'])].append(row)
    entries=[]; merges=[]; corrections=[]
    for key,rows in groups.items():
        # Prefer an unprefixed, concise title. Preserve all originals for traceability.
        selected=min(rows,key=lambda r:(bool(re.match(r'^(a|an|the)\s+',r['term'],re.I)),len(r['term']),r['source_row']))
        item={f:selected[f] for f in FIELDS}
        item['id']='term_'+hashlib.sha256(key.encode()).hexdigest()[:16]
        item['aliases']=sorted(set().union(*(aliases(r['term']) | set(CURATED_ALIASES.get(r['term'], [])) for r in rows)),key=lambda t: (t.casefold(), t))
        item['domain']='CS' if item['category'] in CS else 'AI'
        item['source_rows']=[r['source_row'] for r in rows]
        item['source_records']=rows
        if selected.get('reference'): item['review_reference']=selected['reference']
        item['related_terms']=list(dict.fromkeys(t.strip() for r in rows for t in r['related_terms'].split(';') if t.strip()))
        for original in rows:
            patch=CORRECTIONS.get(original['term'])
            if patch:
                for field,value in patch.items():
                    if field!='reference':item[field]=value
                item['review_reference']=patch['reference']
                corrections.append({'term':item['term'],'fields':[f for f in patch if f!='reference'],'reference':patch['reference']})
        if len(rows)>1:merges.append({'canonical':item['term'],'original_terms':[r['term'] for r in rows],'source_rows':item['source_rows']})
        entries.append(item)
    index=defaultdict(set)
    for e in entries:
        for alias in e['aliases']:index[alias.casefold()].add(e['id'])
    unresolved=[]
    for e in entries:
        links=[]
        for t in e['related_terms']:
            ids=index.get(t.casefold(),set())
            target=next(iter(ids)) if len(ids)==1 else None
            links.append({'term':t,'id':target})
            if target is None:unresolved.append({'entry':e['term'],'related':t})
        e['related_links']=links
    metadata={'source_rows':len(df),'added_entries':len(additions),'entries':len(entries),'merged_groups':len(merges),'categories':sorted(set(e['category'] for e in entries)),
              'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'domain_rule':'Category-based display grouping; interdisciplinary terms retain their original category.'}
    (ROOT/'data/knowledge_base.json').write_text(json.dumps({'metadata':metadata,'entries':entries},ensure_ascii=False,indent=2))
    (ROOT/'data/preparation_report.json').write_text(json.dumps({'metadata':metadata,'merges':merges,'corrections':corrections,'whitespace_changes':changes,'unresolved_related_count':len(unresolved),'unresolved_related':unresolved},ensure_ascii=False,indent=2))
    print(json.dumps(metadata,indent=2))

if __name__=='__main__':main()
